import numpy as np
import matplotlib.pyplot as plt
from grating import grating_response

def main():
    def distance(R_f,R_b):
        return np.abs(R_f-R_b)/2-np.sqrt(R_f*R_b)

    def reflection_transmission(L,Lambda,n0,n_dc,n_ac,a_dc,a_ac,delta_z,wavelengths):
        reflection_f = []
        reflection_b = []
        transmission_f = []
        transmission_b = []
        #distance_to_EP = []

        for wavelength in wavelengths:
            r_f, r_b, t_f, t_b = grating_response(L,Lambda,n0,n_dc,n_ac,a_dc,a_ac,delta_z,wavelength)
            R_f = np.abs(r_f)**2
            R_b = np.abs(r_b)**2
            T_f = np.abs(t_f)**2
            T_b = np.abs(t_b)**2
            reflection_f.append(R_f)
            reflection_b.append(R_b)
            transmission_f.append(T_f)
            transmission_b.append(T_b)

        reflection_f = np.array(reflection_f)
        reflection_b = np.array(reflection_b)
        transmission_f = np.array(transmission_f)
        transmission_b = np.array(transmission_b)
        return reflection_f, reflection_b, transmission_f, transmission_b

    n0 = 1.5
    #n_ac = 1e-3
    n_ac = [1e-4,2e-4,5e-4,1e-3,2e-3,5e-3,1e-2]
    n_dc = 0
    #n_dc = n_ac/2
    a_ac = 5e-4
    a_dc = a_ac/2
    #n_ac = np.linspace(0.5172e-6,0.5174e-6,100000)
    #a_ac = 2.14275e-7
    #a_dc = a_ac/2
    L = 2e-3
    #L = [1e-4,2e-4,5e-4,1e-3,2e-3,5e-3,1e-2]
    Lambda = 534.3e-9
    delta_z = 0


    #idx = 52805
    #n_ac = n_ac[idx]
    #n_dc = n_ac/2

    bragg = 2*(n0+n_dc)*Lambda
    offset = bragg/1000
    wavelengths = np.linspace(bragg-offset,bragg+offset,10000)

    ratios = [0.1,0.2,0.5,1,2,5,10]
    reflections_f = []
    reflections_b = []
    transmissions_f = []
    transmissions_b = []

    for n in n_ac:
        #a_ac = ratio*n_ac
        #a_dc = a_ac/2
        reflection_f, reflection_b, transmission_f, transmission_b = reflection_transmission(L,Lambda,n0,n_dc,n,a_dc,a_ac,delta_z,wavelengths) 
        reflections_f.append(reflection_f)
        reflections_b.append(reflection_b)
        transmissions_f.append(transmission_f)
        transmissions_b.append(transmission_b)
        
        loss_b = 1 - reflection_b - transmission_b
        plt.plot(wavelengths, loss_b, label="n_ac = "+str(n))


    plt.title("Round Trip Loss Vs Wavelength")
    plt.ylabel("Round Trip Loss")
    plt.xlabel("Wavelength (m)")
    plt.legend()
    plt.show()

    return

main()
