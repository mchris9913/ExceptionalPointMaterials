import numpy as np
import matplotlib.pyplot as plt
import cmath as cm

def main():
    def check(n0,n_dc,n_ac,L,wavelength,bragg):
        sigma = 2*np.pi*(n0+n_dc)*(1/wavelength - 1/bragg)
        k = np.pi*n_ac/wavelength
        delta = cm.sqrt(k**2 - sigma**2)
        return -k*np.sinh(delta*L)/(sigma*np.sinh(delta*L)+1j*delta*np.cosh(delta*L))

    
    L = 2e-3
    Lambda = 534.3e-9

    n0 = 1.5
    n_ac = 0.5e-4
    n_dc = n_ac/2

    bragg = 2*(n0 + n_dc)*Lambda
    print(bragg)

    a_ac = 0.5e-6
    a_dc = a_ac/2

    delta_z = 0

    offset = bragg/1000
    wavelengths = np.linspace(bragg-offset,bragg+offset,10000)

    reflection_f = []
    reflection_b = []
    transmission_f = []
    transmission_b = []


    for wavelength in wavelengths:
        beta_tilde = 2*np.pi*(n0 + n_dc + 1j*a_dc)/wavelength
        sigma_hat = beta_tilde - np.pi/Lambda
        
        kn = np.pi*n_ac/wavelength
        ka = np.pi*a_ac/wavelength
        k12 = kn - ka*np.exp(1j*2*np.pi*delta_z/Lambda)
        k21 = kn + ka*np.exp(-1j*2*np.pi*delta_z/Lambda)
        gamma = (k12*k21 - sigma_hat**2)**(1/2)

        m11 = (np.cosh(gamma*L) + 1j*sigma_hat/gamma*np.sinh(gamma*L))*np.exp((-1j*(sigma_hat-beta_tilde)*L))
        m12 = 1j*k12/gamma*np.sinh(gamma*L)*np.exp((-1j*(sigma_hat-beta_tilde)*L))
        m21 = -1j*k21/gamma*np.sinh(gamma*L)*np.exp((1j*(sigma_hat-beta_tilde)*L))
        m22 = (np.cosh(gamma*L) - 1j*sigma_hat/gamma*np.sinh(gamma*L))*np.exp((1j*(sigma_hat-beta_tilde)*L))
        
        r_f = -m21/m22
        r_b = m12/m22
        t_f = m11-m12*m21/m22
        t_b = 1/m22

        reflection_f.append(r_f)
        reflection_b.append(r_b)
        transmission_f.append(t_f)
        transmission_b.append(t_b)

    reflection_f = np.array(reflection_f)
    reflection_b = np.array(reflection_b)
    transmission_f = np.array(transmission_f)
    transmission_b = np.array(transmission_b)
     
    plt.subplot(2,1,1)
    plt.plot(wavelengths, np.abs(transmission_f)**2, label="Forward Transmission")
    plt.plot(wavelengths, np.abs(transmission_b)**2, label="Backward Transmission")
    plt.legend()
    plt.title("Forward/Backward Transmission")
    plt.ylabel("Power Transmission")

    plt.subplot(2,1,2)
    plt.plot(wavelengths, np.abs(transmission_f)-np.abs(transmission_b))
    plt.ylabel("Difference")
    plt.xlabel("Wavelength (m)")
    plt.show()

    return

main()
