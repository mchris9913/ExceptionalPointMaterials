import numpy as np
import matplotlib.pyplot as plt
import cmath as cm

def main():
    def chebychev(a,N):
        return np.sin((N+1)*np.arccos(a))/(np.sqrt(1-a**2))
    
    n0 = 1.5
    n1 = np.sqrt(13.095)
    n2 = np.sqrt(13.1 + 1j*0.055)
    a = 0.276e-6
    d1 = 0.49455*a
    d2 = (1-0.49455)*a
    bragg = 2*(np.real(n1)*d1 + np.real(n2)*d2)
    d0 = bragg/n0

    offset = bragg/1000
    wavelengths = np.linspace(bragg-offset,bragg+offset,100000)
    p0 = np.real(n0)
    p1 = np.real(n1)
    p2 = np.real(n2)
    reflection_f = []
    transmission_f = []
    reflection_b = []
    transmission_b = []

    pf = p1
    pl = p2

    N = 85926/2
    for wavelength in wavelengths:
        beta0 = 2*np.pi/wavelength*n0*d0
        beta1 = 2*np.pi/wavelength*n1*d1
        beta2 = 2*np.pi/wavelength*n2*d2
        M0 = np.array([[np.cos(beta0), -1j/p0*np.sin(beta0)],[-1j*p0*np.sin(beta0), np.cos(beta0)]])
        M1 = np.array([[np.cos(beta1), -1j/p1*np.sin(beta1)],[-1j*p1*np.sin(beta1), np.cos(beta1)]])
        M2 = np.array([[np.cos(beta2), -1j/p2*np.sin(beta2)],[-1j*p2*np.sin(beta2), np.cos(beta2)]])
        M = M1 @ M2
        
        a = 1/2*(M[0,0] + M[1,1])
        m11 = M[0,0]*chebychev(a,N-1) - chebychev(a,N-2)
        m12 = M[0,1]*chebychev(a,N-1)
        m21 = M[1,0]*chebychev(a,N-1)
        m22 = M[1,1]*chebychev(a,N-1) - chebychev(a,N-2)

        #M = M0 @ np.array([[m11,m12],[m21,m22]]) @ M0
        #m11 = M[0,0]
        #m12 = M[0,1]
        #m21 = M[1,0]
        #m22 = M[1,1]

        r = ((m11+m12*pl)*pf-(m21+m22*pl))/((m11+m12*pl)*pf + (m21 + m22*pl))
        t = 2*pf/((m11+m12*pl)*pf + (m21 + m22*pl))
        reflection_f.append(r)
        transmission_f.append(t)

    pf = p2
    pl = p1

    for wavelength in wavelengths:
        beta0 = 2*np.pi/wavelength*n0*d0
        beta1 = 2*np.pi/wavelength*n1*d1
        beta2 = 2*np.pi/wavelength*n2*d2
        M0 = np.array([[np.cos(beta0), -1j/p1*np.sin(beta0)],[-1j*p1*np.sin(beta0), np.cos(beta0)]])
        M1 = np.array([[np.cos(beta1), -1j/p1*np.sin(beta1)],[-1j*p1*np.sin(beta1), np.cos(beta1)]])
        M2 = np.array([[np.cos(beta2), -1j/p2*np.sin(beta2)],[-1j*p2*np.sin(beta2), np.cos(beta2)]])
        M = M2 @ M1
        
        a = 1/2*(M[0,0] + M[1,1])
        m11 = M[0,0]*chebychev(a,N-1) - chebychev(a,N-2)
        m12 = M[0,1]*chebychev(a,N-1)
        m21 = M[1,0]*chebychev(a,N-1)
        m22 = M[1,1]*chebychev(a,N-1) - chebychev(a,N-2)
        
        #M = M0 @ np.array([[m11,m12],[m21,m22]]) @ M0
        #m11 = M[0,0]
        #m12 = M[0,1]
        #m21 = M[1,0]
        #m22 = M[1,1]

        r = ((m11+m12*pl)*pf-(m21+m22*pl))/((m11+m12*pl)*pf + (m21 + m22*pl))
        t = 2*pf/((m11+m12*pl)*pf + (m21 + m22*pl))
        reflection_b.append(r)
        transmission_b.append(t)

    transmission_f = np.array(transmission_f)
    transmission_b = np.array(transmission_b)
    reflection_b = np.array(reflection_b)
    reflection_f = np.array(reflection_f)


    """
    plt.subplot(2,1,1)
    plt.plot(wavelengths, np.abs(reflection_f),label="Reflection CW Direction")
    plt.plot(wavelengths, np.abs(reflection_b),label="Reflection CCW Direction")
    plt.title("Reflection Adding An Extra Material (n0) To The Beginning And End Of Stack (N = 85926)")
    plt.ylabel("Reflectivity")
    plt.legend()

    plt.subplot(2,1,2)
    plt.plot(wavelengths, np.abs(reflection_f)-np.abs(reflection_b))
    plt.title("Difference in Reflection Between CW and CCW")
    plt.ylabel("Difference in Reflectivity")
    plt.xlabel("Wavelength (m)")
    plt.show()
    """

    Loss_f = 1 - np.abs(reflection_f)**2 - p2/p1*np.abs(transmission_f)**2
    Loss_b = 1 - np.abs(reflection_b)**2 - p1/p2*np.abs(transmission_b)**2

    
    plt.subplot(2,1,1)
    plt.plot(wavelengths, np.abs(reflection_f)**2,label="Reflectivity CCW")
    #plt.plot(wavelengths, p2/p1*np.abs(transmission_f)**2,label="Transmitivity CCW")
    plt.plot(wavelengths, np.abs(reflection_b)**2,label="Reflectivity CW")
    #plt.plot(wavelengths, p1/p2*np.abs(transmission_b)**2,label="Transmitivity CW")
    plt.title("Power Reflection Versus Wavelengths")
    plt.legend()

    plt.subplot(2,1,2)
    #plt.plot(wavelengths, p2/p1*np.abs(transmission_f)**2 - p1/p2*np.abs(transmission_b)**2)
    plt.plot(wavelengths, np.abs(reflection_f)**2 - np.abs(reflection_b)**2)
    #plt.plot(wavelengths, Loss_f, label="Loss CCW")
    #plt.plot(wavelengths, Loss_b, label="Loss CCW")
    plt.title("Difference In Reflection")
    plt.xlabel("Wavelength (m)")
    plt.legend()
    plt.show()
    
    
    """
    plt.subplot(2,1,1)
    plt.plot(wavelengths, np.abs(reflection_f)**2-np.abs(reflection_b)**2)
    plt.title("Differential Power Reflectivity")
    
    plt.subplot(2,1,2)
    plt.plot(wavelengths, Loss_f - Loss_b)
    plt.title("Differential Loss")
    plt.xlabel("Wavelength (m)")
    plt.show()
    """

    """
    plt.plot(wavelengths, Loss_f - Loss_b)
    plt.title("Differential Loss")
    plt.xlabel("Wavelength (m)")
    #plt.ylim(-0.03,0.03)
    plt.show()
    """

    return

main()
