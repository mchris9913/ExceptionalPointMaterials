import numpy as np
import matplotlib.pyplot as plt

def main():
    n1 = 1.5
    n2 = 1.501
    Lambda = 534.3e-9
    bragg = 2*(n1+n2)/2*Lambda
    d = Lambda/2
    r12 = np.real(n1-n2)/np.real(n1+n2)
    r21 = np.real(n2-n1)/np.real(n1+n2)
    t12 = np.real(2*n1)/np.real(n1+n2)
    t21 = np.real(2*n2)/np.real(n1+n2)
    N = 3

    offset = bragg/100
    wavelengths1 = np.linspace(bragg-offset,bragg+offset,1000)
    reflection_f = []
    reflection_b = []
    for wavelength in wavelengths1:
        phi1 = 2*np.pi*n1*d/wavelength
        phi2 = 2*np.pi*n2*d/wavelength
        delta = (t12*t21)**2*np.exp(-2*1j*phi1 -2*1j*phi2)
        Delta = (delta-delta**(N+1))/(1-delta)
        r_f = (r21 + (r12*np.exp(2*1j*phi2)/(t12*t21)+r21)*Delta)
        r_b = (r12 + (r21*np.exp(2*1j*phi1)/(t12*t21)+r12)*Delta)
        reflection_f.append(r_f)
        reflection_b.append(r_b)

    reflection_1f = np.array(reflection_f)
    reflection_1b = np.array(reflection_b)

    n2 = 1.6
    r12 = np.real(n1-n2)/np.real(n1+n2)
    r21 = np.real(n2-n1)/np.real(n1+n2)
    t12 = np.real(2*n1)/np.real(n1+n2)
    t21 = np.real(2*n2)/np.real(n1+n2)
    bragg = 2*(n1+n2)/2*Lambda
    d = Lambda/2

    offset = bragg/100
    wavelengths2 = np.linspace(bragg-offset,bragg+offset,1000)
    reflection_f = []
    reflection_b = []
    for wavelength in wavelengths2:
        phi1 = 2*np.pi*n1*d/wavelength
        phi2 = 2*np.pi*n2*d/wavelength
        delta = (t12*t21)**2*np.exp(-2*1j*phi1 -2*1j*phi2)
        Delta = (delta-delta**(N+1))/(1-delta)
        r_f = (r21 + (r12*np.exp(2*1j*phi2)/(t12*t21)+r21)*Delta)
        r_b = (r12 + (r21*np.exp(2*1j*phi1)/(t12*t21)+r12)*Delta)
        reflection_f.append(r_f)
        reflection_b.append(r_b)
    
    reflection_2f = np.array(reflection_f)
    reflection_2b = np.array(reflection_b) 

    n2 = 1.7
    r12 = np.real(n1-n2)/np.real(n1+n2)
    r21 = np.real(n2-n1)/np.real(n1+n2)
    t12 = np.real(2*n1)/np.real(n1+n2)
    t21 = np.real(2*n2)/np.real(n1+n2)
    bragg = 2*(n1+n2)/2*Lambda
    d = Lambda/2

    offset = bragg/100
    wavelengths3 = np.linspace(bragg-offset,bragg+offset,1000)
    reflection_f = []
    reflection_b = []
    for wavelength in wavelengths3:
        phi1 = 2*np.pi*n1*d/wavelength
        phi2 = 2*np.pi*n2*d/wavelength
        delta = (t12*t21)**2*np.exp(-2*1j*phi1 -2*1j*phi2)
        Delta = (delta-delta**(N+1))/(1-delta)
        r_f = (r21 + (r12*np.exp(2*1j*phi2)/(t12*t21)+r21)*Delta)
        r_b = (r12 + (r21*np.exp(2*1j*phi1)/(t12*t21)+r12)*Delta)
        reflection_f.append(r_f)
        reflection_b.append(r_b)
    
    reflection_3f = np.array(reflection_f)
    reflection_3b = np.array(reflection_b) 

    plt.subplot(3,2,1)
    plt.plot(wavelengths1, np.abs(reflection_1f),label="n2 = 1.501 Reflection CW Dir")
    plt.plot(wavelengths1, np.abs(reflection_1b),label="n2 = 1.501 Reflection CCW Dir")
    plt.ylabel("Field Reflection")
    plt.title("Field Reflection Coefficient Direction Comparison")
    plt.legend()

    plt.subplot(3,2,2)
    plt.plot(wavelengths1, np.abs(reflection_1f)-np.abs(reflection_1b),label="n2 = 1.501 Amplitude Difference")
    plt.ylabel("Reflection Difference")
    plt.title("Field Reflection Amplitude Difference")
    plt.legend()

    plt.subplot(3,2,3)
    plt.plot(wavelengths2, np.abs(reflection_2f),label="n2 = 1.6 Reflection CW Dir")
    plt.plot(wavelengths2, np.abs(reflection_2b),label="n2 = 1.6 Reflection CCW Dir")
    plt.ylabel("Field Reflection")
    plt.legend()

    plt.subplot(3,2,4)
    plt.plot(wavelengths2, np.abs(reflection_2f)-np.abs(reflection_2b),label="n2 = 1.6 Amplitude Difference")
    plt.ylabel("Reflection Difference")
    plt.legend()

    plt.subplot(3,2,5)
    plt.plot(wavelengths3, np.abs(reflection_3f),label="n2 = 1.7 Reflection CW Dir")
    plt.plot(wavelengths3, np.abs(reflection_3b),label="n2 = 1.7 Reflection CCW Dir")
    plt.ylabel("Field Reflection")
    plt.xlabel("Wavelength (m)")
    plt.legend()

    plt.subplot(3,2,6)
    plt.plot(wavelengths3, np.abs(reflection_3f)-np.abs(reflection_3b),label="n2 = 1.7 Amplitude Difference")
    plt.ylabel("Reflection Difference")
    plt.xlabel("Wavelength (m)")
    plt.legend()
    plt.show()

    return

def main2():
    n1 = np.sqrt(13.095)
    n2 = np.sqrt(13.1 - 1j*0.055)
    a = 0.276e-6
    d1 = 0.49455*a
    d2 = a - d1
    bragg = 2*(np.real(n1)*d1 + np.real(n2)*d2)
    print(bragg)
    r12 = np.real(n1-n2)/np.real(n1+n2)
    r21 = np.real(n2-n1)/np.real(n1+n2)
    t12 = np.real(2*n1)/np.real(n1+n2)
    t21 = np.real(2*n2)/np.real(n1+n2)
    N1 = 1000
    N2 = 2000

    offset = bragg/1000
    wavelengths1 = np.linspace(bragg-offset,bragg+offset,10000)
    reflection_1f = []
    reflection_1b = []
    reflection_2f = []
    reflection_2b = []
    for wavelength in wavelengths1:
        phi1 = 2*np.pi*n1*d1/wavelength
        phi2 = 2*np.pi*n2*d2/wavelength
        delta = (t12*t21)**2*np.exp(-2*1j*phi1 -2*1j*phi2)
        Delta1 = (delta - delta**(N1+1))/(1-delta)
        Delta2 = (delta - delta**(N2+1))/(1-delta)
        r_f1 = (r21 + (r12*np.exp(2*1j*phi2)/(t12*t21)+r21)*Delta1)
        r_b1 = (r12 + (r21*np.exp(2*1j*phi1)/(t12*t21)+r12)*Delta1)
        r_f2 = (r21 + (r12*np.exp(2*1j*phi2)/(t12*t21)+r21)*Delta2)
        r_b2 = (r12 + (r21*np.exp(2*1j*phi1)/(t12*t21)+r12)*Delta2)

        reflection_1f.append(np.abs(r_f1))
        reflection_1b.append(np.abs(r_b1))
        reflection_2f.append(np.abs(r_f2))
        reflection_2b.append(np.abs(r_b2))

    reflection_1f = np.array(reflection_1f)
    reflection_1b = np.array(reflection_1b)
    reflection_2f = np.array(reflection_2f)
    reflection_2b = np.array(reflection_2b)
    
    plt.subplot(2,1,1)
    plt.plot(wavelengths1, np.abs(reflection_1f),label="2000 Cells CW Dir")
    plt.plot(wavelengths1, np.abs(reflection_1b),label="2000 Cells CCW Dir")
    plt.plot(wavelengths1, np.abs(reflection_2f),label="4000 Cells CW Dir")
    plt.plot(wavelengths1, np.abs(reflection_2b),label="4000 Cells CCW Dir")
    plt.ylabel("Field Reflection")
    plt.title("Field Reflection Coefficient Comparison")
    plt.legend()

    plt.subplot(2,1,2)
    plt.plot(wavelengths1, np.abs(reflection_1f)-np.abs(reflection_1b),label="20 Cell Amp Difference")
    plt.plot(wavelengths1, np.abs(reflection_2f)-np.abs(reflection_2b),label="4000 Cell Amp Difference")
    plt.ylabel("Reflection Difference")
    plt.xlabel("Wavelength (m)")
    plt.title("Field Reflection Amplitude Difference")
    plt.legend()
    plt.show()

    return

main2()
