import numpy as np

def grating_response(L,Lambda,n0,n_dc,n_ac,a_dc,a_ac,delta_z,wavelength):
    beta_tilde = 2*np.pi*(n0 + n_dc + 1j*a_dc)/wavelength
    sigma_hat = beta_tilde - np.pi/Lambda
        
    kn = np.pi*n_ac/wavelength
    ka = np.pi*a_ac/wavelength
    k12 = kn - ka*np.exp(1j*2*np.pi*delta_z/Lambda)
    k21 = kn + ka*np.exp(-1j*2*np.pi*delta_z/Lambda)
    gamma = (k12*k21 - sigma_hat**2)**(1/2)

    m11 = (np.cosh(gamma*L) + 1j*sigma_hat/gamma*np.sinh(gamma*L))*np.exp((-1j*(sigma_hat-beta_tilde)*L))
    m12 = 1j*k12/gamma*np.sinh(gamma*L)*np.exp((-1j*(sigma_hat-beta_tilde)*L))
    m21 = -1j*k21/gamma*np.sinh(gamma*L)*np.exp((1j*(sigma_hat-beta_tilde)*L))
    m22 = (np.cosh(gamma*L) - 1j*sigma_hat/gamma*np.sinh(gamma*L))*np.exp((1j*(sigma_hat-beta_tilde)*L))
        
    r_f = -m21/m22
    r_b = m12/m22
    t_f = m11-m12*m21/m22
    t_b = 1/m22

    return (r_f, r_b, t_f, t_b) 


