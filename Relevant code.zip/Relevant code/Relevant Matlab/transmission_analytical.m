function T = transmission_analytical(D,ws,kin,L1,L2,k1,k2)
    t = 1 - (2*kin*(L2 + 1j*(D-ws)))./((k1*k2 + L2*L1 - D.^2 + ws.^2) + 1j*((L1 + L2)*D + (L2 - L1)*ws));
    T = abs(t).^2;
end
