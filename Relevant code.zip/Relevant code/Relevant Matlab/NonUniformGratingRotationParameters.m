%% Parameters

c = 3e8;

% Ring Specifics
bragg = 1.6029002763963882e-06;
Len = 2e-3;
n0 = 1.5;
n_dc = 2.586528055280553e-07;
a_ac = 2.14275e-7; 
neff = n0+n_dc;

% Conversions
coupling_conversion = c/(2*Len*neff);
loss_conversion = c/(2*neff);

% Field Coefficients
% aL = 2*pi/bragg*a_ac;
L_ccw = 0.0016736454958822256/Len;
L_cw = 0.00168044684351365/Len;
K_ccw = 8.209952846854138e-06;
K_cw = 1.408605215516508e-06;

% Rate Coefficients
l_ccw = L_ccw * loss_conversion;
l_cw = L_cw * loss_conversion;
k_ccw = K_ccw * coupling_conversion;
k_cw = K_cw * coupling_conversion;
