function T = transmission_two_ring(D,ws,kin,L1,L2,k)
    Lavg = (L1+L2+kin)/2;
    Ldiff = L1 + kin - L2;
    D1 = D - ws;
    D2 = D + ws;
    T = 1 - 4*kin*(k^2*L2 + L1*L2^2 + L1*(D2).^2) ./ ((k^2 + L2*(L1+kin) - D1 .* D2).^2 + (L2*D1 + (L1 + kin)*D2).^2);
end