function s = sensitivity(w,wo,ws,L,kin,kcw,kccw,Pin,h)
    s = zeros(size(ws));
    for i = 1:length(ws)
        high = abs(transmission_single(w,wo,ws(i)+h,L,kin,kcw,kccw,Pin))^2;
        low = abs(transmission_single(w,wo,ws(i)-h,L,kin,kcw,kccw,Pin))^2;  
        s(i) = (high-low)/(2*h);
    end
end