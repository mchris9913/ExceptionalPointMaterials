function t = transmission_single(w,wo,ws,L,kin,kcw,kccw,Pin)
    A = dynamics_sunada(wo,ws,L,kin,kcw,kccw);
    B = [-sqrt(2*kin);0];
    sample = -1j*w*eye(2) - A;
    t = sample^-1*B*Pin;
    t = 1+sqrt(2*kin)*t(1);
end